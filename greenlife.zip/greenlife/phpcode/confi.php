<?php
$con=mysqli_connect("localhost","root","","greenlife") or die("cant connect to database");
?>