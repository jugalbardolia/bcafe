<?php
include "./confi.php";
$err="";
if(isset($_POST['lg']))
{
  $u=$_POST['txtuser'];
  $p=$_POST['pass'];
  $pa=md5($p);
  $sql="select * from users where username='$u'";
  $res=mysqli_query($con,$sql);
  if(mysqli_num_rows($res)>0){
    $sql2="select * from users where username='$u' and password='$pa'";
    $res2=mysqli_query($con,$sql2);
    // print_r ($res2);
    if(mysqli_num_rows($res2)==1){
      header("location:./q1.html");
    }
    else{
      $err="Password Incorrect";
    }
  }
  else{
    $err="No Username Found";
  }

} 
?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Login</title>
    <link href="../css/bootstrap.min.css" rel="stylesheet" >
  </head>
  <style>
    .fffff:hover {
      color: transparent;
      -webkit-text-stroke: 2px black;
    }
  
    .ddd::placeholder {
      color: rgba(250, 235, 215, 0.596);
      padding: 3px;
    }
  
    .bu {
      background-color: rgba(231, 44, 72, 0.8 );
      color: antiquewhite;
    }
  
    .bu:hover {
      background-color: rgba(231, 44, 72);
      color: antiquewhite;
    }
    input{
      background-color: transparent !important;
      color: antiquewhite !important;
      border: 1px solid antiquewhite !important;
      
    }
  
    a {
      margin-left: 2px;
      font-weight: bolder;
      text-decoration: none;
      color: rgba(231, 44, 72, 0.8);
    }
  
    a:hover {
      color: rgba(231, 44, 72);
      text-decoration: underline;
    }
  </style>
  <body>
    <section class="vh-100" style="background:linear-gradient(to right ,rgba(0, 0, 0, 0.4),rgba(122, 245, 115, 0.6));">
  <div class="container h-100">
    <div class="row d-flex justify-content-center align-items-center h-100" >
      <div  class="col-lg-12 col-xl-11">
        <div class="card text-black" style="border-radius: 25px;border: none;background:linear-gradient(to right,rgba(103, 235, 109, 0.8),rgba(231, 44, 72, 0.8));">
          <div class="card-body p-md-5" >
            <div class="row justify-content-center">
              <div class="col-md-10 col-lg-6 col-xl-5 order-2 order-lg-1">

                <p class="fffff text-center h1 fw-bold mb-5 mx-1 mx-md-4 mt-4" >Sign in</p>

                <form class="mx-1 mx-md-4" method="POST" action="<?php  $_SERVER['PHP_SELF'] ?>">
                <p style="color: red;margin-bottom: 15px;font-weight: 500;font-family: revert;     border-radius: 7px;padding: 8px 14px;  "> <?php echo($err); ?></p>

                 
                    <div class="form-outline flex-fill mb-0">
                      <input type="text" id="form3Example1c" class="form-control ddd mb-4" placeholder="Your UserName" required name="txtuser"/>
                      
                    </div>
                  

                  

                  
                    <div class="form-outline flex-fill mb-0">
                      <input type="password" id="form3Example4c" class="form-control ddd mb-4" placeholder="Password" required name="pass"/>
                      
                    </div>
                  

                  

                  

                  <div class="mt-4">
                    <button type="submit"  style="width: 100%;" class="btn bu btn-lg" name="lg">Login</button>
                  </div>
                  <h5 class="mt-4 ms-2" style="color: bisque;"> Click Here For Register: <a   href="registration.php" >Register</a></h5>
                </form>

              </div>
              <div class="col-md-10  col-lg-6 col-xl-7 d-flex align-items-center order-1 order-lg-2 ">

                <img style="border-radius: 20px; height: 400px; width: 300px; margin-left: 125px ; margin-top: 30px;" src="https://cdn.pixabay.com/photo/2020/10/14/18/35/sign-post-5655110_1280.png"
                  class="img-fluid" alt="Sample image">

              </div>
            </div>
            
        </div>
        </div>
      </div>
    </div>
  </div>
</section>
    <script src="../js/bootstrap.bundle.min.js" ></script>
  </body>
</html>